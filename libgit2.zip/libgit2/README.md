## HydraLauncherLibs_Windows_x64

These builds are of [libgit2](https://github.com/libgit2/libgit2/tree/21a351b0ed207d0871cb23e09c027d1ee42eae98), which is licensed under the GPL-2.0 with linking exception.

This repo provides precompiled binaries for convenience only. All rights belong to the original authors.
